import pymysql.cursors

# подключаемся к базе данных
def get_db_connection():
    return pymysql.connect(
        host='localhost',
        user='root',
        password='',
        database='university_docs',
        cursorclass=pymysql.cursors.DictCursor
    )