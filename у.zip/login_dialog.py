from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLineEdit, QPushButton, QMessageBox
from database import get_db_connection


class LoginDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Вход в систему документооборота")
        self.setFixedSize(350, 200)

        layout = QVBoxLayout()

        self.username_input = QLineEdit(placeholderText="Логин")

        self.password_input = QLineEdit(placeholderText="Пароль", echoMode=QLineEdit.EchoMode.Password)

        login_btn = QPushButton("Войти")
        login_btn.clicked.connect(self.authenticate)  # привязываем метод аутентификации

        layout.addWidget(self.username_input)
        layout.addWidget(self.password_input)
        layout.addWidget(login_btn)

        self.setLayout(layout)

    def authenticate(self):
        # метод для проверки учетных данных пользователя
        username = self.username_input.text().strip()  # удаляем лишние пробелы
        password = self.password_input.text().strip()

        if not username or not password:
            QMessageBox.warning(self, "Ошибка", "Логин и пароль не могут быть пустыми")
            return

        try:
            conn = get_db_connection()
            with conn.cursor() as cursor:
                sql = "SELECT * FROM users WHERE login=%s AND password=%s"
                cursor.execute(sql, (username, password))
                user = cursor.fetchone()  # получаем первую найденную запись

                if user:
                    self.user_data = user
                    self.accept()
                else:
                    QMessageBox.warning(
                        self,
                        "Ошибка",
                        "Неверные учетные данные. Проверьте логин и пароль."
                    )

        except Exception as e:
            QMessageBox.critical(
                self,
                "Ошибка",
                f"Ошибка подключения к базе данных: {str(e)}"
            )
        finally:
            if 'conn' in locals():
                conn.close()