from PyQt6.QtWidgets import QApplication, QDialog
from login_dialog import LoginDialog
from user_window import UserWindow
from admin_window import AdminWindow
import sys

if __name__ == "__main__":
    app = QApplication(sys.argv)

    while True:
        login_dialog = LoginDialog()
        if login_dialog.exec() != QDialog.DialogCode.Accepted:
            break

        user_data = login_dialog.user_data

        if user_data['role'] == 'admin':
            window = AdminWindow(user_data, login_dialog)
        else:
            window = UserWindow(user_data, login_dialog)

        window.show()
        app.exec()

        # очищаем окно для следующего входа
        if hasattr(app, 'window'):
            app.window = None

    sys.exit()