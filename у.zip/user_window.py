from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
 QPushButton, QFileDialog, QMessageBox, QLabel, QComboBox, QHeaderView, QDialog, QAbstractItemView, QTextEdit)
from PyQt6.QtCore import Qt
from database import get_db_connection
import os

class UserWindow(QMainWindow):
    def __init__(self, user_data, login_dialog):
        super().__init__()
        self.user_data = user_data
        self.login_dialog = login_dialog
        self.setWindowTitle(f"Документооборот")
        self.setGeometry(100, 100, 900, 500)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        self.layout = QVBoxLayout()
        self.central_widget.setLayout(self.layout)

        # фильтрация по статусу
        self.create_filters_panel()
        self.create_buttons_panel()
        self.create_documents_table()

        self.load_initial_data()

    def create_filters_panel(self):
        # фильтрация по статусу
        filters_layout = QHBoxLayout()
        self.status_filter = QComboBox()
        self.status_filter.addItems(["Все статусы", "Черновик", "На рассмотрении", "Утвержден", "Отклонен"])
        filters_layout.addWidget(QLabel("Статус:"))
        filters_layout.addWidget(self.status_filter)

        self.apply_filters_btn = QPushButton("Применить")
        self.apply_filters_btn.clicked.connect(self.apply_filters)
        filters_layout.addWidget(self.apply_filters_btn)

        self.layout.addLayout(filters_layout)

    def create_buttons_panel(self):
        # кнопки
        buttons_layout = QHBoxLayout()

        self.back_btn = QPushButton("Назад")
        self.back_btn.clicked.connect(self.back_to_login)
        buttons_layout.addWidget(self.back_btn)

        self.create_request_btn = QPushButton("Создать заявку и добавить документ")
        self.create_request_btn.clicked.connect(self.create_request_and_add_document)
        buttons_layout.addWidget(self.create_request_btn)

        self.check_completeness_btn = QPushButton("Проверить комплектность")
        self.check_completeness_btn.clicked.connect(self.check_completeness)
        buttons_layout.addWidget(self.check_completeness_btn)

        self.check_signature_btn = QPushButton("Проверить подпись")
        self.check_signature_btn.clicked.connect(self.check_signature)
        buttons_layout.addWidget(self.check_signature_btn)

        self.layout.addLayout(buttons_layout)

    def create_documents_table(self):
        # таблца документов
        self.doc_table = QTableWidget()
        self.doc_table.setColumnCount(7)
        self.doc_table.setHorizontalHeaderLabels(
            ["ID", "Название", "Тип", "Статус", "Подпись", "Дата", "Подразделение"])
        self.doc_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.doc_table.doubleClicked.connect(self.show_document_details)
        self.doc_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.doc_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.doc_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.layout.addWidget(self.doc_table)

    def load_initial_data(self):
        # загруаем локументы из бд
        self.load_documents()

    def load_documents(self):
        # загруаем локументы из бд в таблицу
        try:
            conn = get_db_connection()
            with conn.cursor() as cursor:
                cursor.execute("""
                    SELECT d.id, d.title, dt.description AS type, ds.description AS status, 
                           d.is_signed, d.created_at, u.department
                    FROM documents d
                    JOIN users u ON d.user_id = u.id
                    JOIN document_types dt ON d.type_id = dt.id
                    JOIN document_statuses ds ON d.status_id = ds.id
                    WHERE d.user_id = %s
                    ORDER BY d.created_at DESC
                """, (self.user_data['id'],))
                docs = cursor.fetchall()

                self.doc_table.setRowCount(len(docs))
                for row, doc in enumerate(docs):
                    for col, value in enumerate([
                        str(doc['id']),
                        doc['title'],
                        doc['type'],
                        doc['status'],
                        "подпись есть" if doc['is_signed'] else "подписи нет",
                        str(doc['created_at']),
                        doc['department'] or ""
                    ]):
                        item = QTableWidgetItem(value)
                        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)  # Запрет редактирования
                        self.doc_table.setItem(row, col, item)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить документы: {str(e)}")
        finally:
            if conn:
                conn.close()

    def apply_filters(self):
        # кнопка применить фильтрацию
        try:
            conn = get_db_connection()
            with conn.cursor() as cursor:
                sql = """
                    SELECT d.id, d.title, dt.description AS type, ds.description AS status, 
                           d.is_signed, d.created_at, u.department
                    FROM documents d
                    JOIN users u ON d.user_id = u.id
                    JOIN document_types dt ON d.type_id = dt.id
                    JOIN document_statuses ds ON d.status_id = ds.id
                    WHERE d.user_id = %s
                """
                params = [self.user_data['id']]
                conditions = []

                # фильтр по статусу
                status_map = {
                    "Черновик": 1,  # draft
                    "На рассмотрении": 2,  # pending
                    "Утвержден": 3,  # approved
                    "Отклонен": 4   # rejected
                }
                status_filter = self.status_filter.currentText()
                if status_filter != "Все статусы":
                    conditions.append("ds.id = %s")
                    params.append(status_map[status_filter])

                if conditions:
                    sql += " AND " + " AND ".join(conditions)

                sql += " ORDER BY d.created_at DESC"

                cursor.execute(sql, params)
                docs = cursor.fetchall()

                self.doc_table.setRowCount(len(docs))
                for row, doc in enumerate(docs):
                    for col, value in enumerate([
                        str(doc['id']),
                        doc['title'],
                        doc['type'],
                        doc['status'],
                        "✓" if doc['is_signed'] else "✗",
                        str(doc['created_at']),
                        doc['department'] or ""
                    ]):
                        item = QTableWidgetItem(value)
                        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                        self.doc_table.setItem(row, col, item)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка фильтрации: {str(e)}")
        finally:
            if conn:
                conn.close()

    def create_request_and_add_document(self):
        # окно создания заявки и добавления документа
        dialog = QDialog(self)
        dialog.setWindowTitle("Создать новую заявку")
        dialog.setModal(True)
        dialog.resize(600, 400)

        layout = QVBoxLayout()
        type_layout = QHBoxLayout()
        type_layout.addWidget(QLabel("Тип заявки:"))
        request_type_combo = QComboBox()
        request_type_combo.addItems(["Регистрация", "Проверка", "Коррекция", "Другое"])
        type_layout.addWidget(request_type_combo)
        layout.addLayout(type_layout)

        priority_layout = QHBoxLayout()
        priority_layout.addWidget(QLabel("Приоритет:"))
        priority_combo = QComboBox()
        priority_combo.addItems(["Низкий", "Средний", "Высокий"])
        priority_layout.addWidget(priority_combo)
        layout.addLayout(priority_layout)

        layout.addWidget(QLabel("Комментарий:"))
        comment_text = QTextEdit()
        comment_text.setPlaceholderText("Опишите суть заявки...")
        layout.addWidget(comment_text)

        file_label = QLabel("Документ: Не выбран")
        layout.addWidget(file_label)
        file_path = [None]

        def choose_file():
            # выбираем документ
            path, _ = QFileDialog.getOpenFileName(dialog, "Выберите документ", "",
                                                 "All Files (*);;Text Files (*.txt);;Documents (*.docx *.pdf)")
            if path:
                file_path[0] = path
                file_label.setText(f"Документ: {os.path.basename(path)}")

        file_btn = QPushButton("Выбрать документ")
        file_btn.clicked.connect(choose_file)
        layout.addWidget(file_btn)

        buttons = QHBoxLayout()
        submit_btn = QPushButton("Создать")
        def submit_request():
            request_type = request_type_combo.currentText()
            priority = priority_combo.currentText()
            comment = comment_text.toPlainText().strip()

            if not comment:
                QMessageBox.warning(dialog, "Ошибка", "Введите комментарий к заявке")
                return
            if not file_path[0]:
                QMessageBox.warning(dialog, "Ошибка", "Выберите документ")
                return

            # Маппинг значений на ID
            type_map = {
                "Регистрация": 1,
                "Проверка": 2,
                "Коррекция": 3,
                "Другое": 4
            }
            priority_map = {
                "Низкий": 1,
                "Средний": 2,
                "Высокий": 3
            }
            doc_type_map = {
                '.xlsx': 1,
                '.docx': 2,
                '.pdf': 2,
                '.txt': 2
            }

            db_request_type_id = type_map.get(request_type, 4)  # по умолчанию other
            db_priority_id = priority_map.get(priority, 2)      # по умолчанию medium
            db_status_id = 1                                   # new по умолчанию
            doc_extension = os.path.splitext(file_path[0])[1].lower()
            db_doc_type_id = doc_type_map.get(doc_extension, 2) # по умолчанию docx

            try:
                conn = get_db_connection()
                with conn.cursor() as cursor:
                    cursor.execute("""
                        INSERT INTO requests (type_id, status_id, priority_id, comment, user_id, created_at)
                        VALUES (%s, %s, %s, %s, %s, NOW())
                    """, (db_request_type_id, db_status_id, db_priority_id, comment, self.user_data['id']))
                    request_id = cursor.lastrowid

                    cursor.execute("""
                        INSERT INTO documents (title, type_id, file_path, status_id, user_id, created_at)
                        VALUES (%s, %s, %s, %s, %s, NOW())
                    """, (os.path.basename(file_path[0]), db_doc_type_id, file_path[0], 1, self.user_data['id']))
                    doc_id = cursor.lastrowid

                    cursor.execute("""
                        INSERT INTO request_documents (request_id, document_id)
                        VALUES (%s, %s)
                    """, (request_id, doc_id))
                    conn.commit()

                QMessageBox.information(dialog, "Успех", f"Заявка #{request_id} и документ успешно созданы")
                dialog.accept()
                self.load_documents()

            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось создать заявку: {str(e)}")
            finally:
                if conn:
                    conn.close()

        submit_btn.clicked.connect(submit_request)
        buttons.addWidget(submit_btn)

        cancel_btn = QPushButton("Отмена")
        cancel_btn.clicked.connect(dialog.reject)
        buttons.addWidget(cancel_btn)

        layout.addLayout(buttons)
        dialog.setLayout(layout)
        dialog.exec()

    def check_completeness(self):
        # вывод сообщения о комплектости
        selected = self.doc_table.currentRow()
        if selected >= 0:
            doc_id = self.doc_table.item(selected, 0).text()
            doc_name = self.doc_table.item(selected, 1).text()
            try:
                conn = get_db_connection()
                with conn.cursor() as cursor:
                    cursor.execute("""
                        SELECT COUNT(*) AS count
                        FROM request_documents rd
                        WHERE rd.document_id = %s
                    """, (doc_id,))
                    result = cursor.fetchone()

                    if result['count'] > 0:
                        QMessageBox.information(self, "Проверка комплектности", "Все документы есть")
                    else:
                        QMessageBox.warning(self, "Проверка комплектности", f"Отсутствует связь с заявкой для документа: {doc_name}")
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Ошибка проверки: {str(e)}")
            finally:
                if conn:
                    conn.close()
        else:
            QMessageBox.warning(self, "Ошибка", "Выберите документ для проверки")

    def check_signature(self):
        # проверка подписи
        selected = self.doc_table.currentRow()
        if selected >= 0:
            doc_id = self.doc_table.item(selected, 0).text()
            try:
                conn = get_db_connection()
                with conn.cursor() as cursor:
                    cursor.execute("""
                        SELECT d.is_signed, d.created_at, 
                               CONCAT(u.first_name, ' ', COALESCE(u.last_name, ''), ' ', COALESCE(u.middle_name, '')) AS author
                        FROM documents d
                        JOIN users u ON d.user_id = u.id
                        WHERE d.id = %s
                    """, (doc_id,))
                    doc = cursor.fetchone()

                    if doc:
                        is_signed = doc['is_signed']
                        author = doc['author'].strip()
                        created_at = doc['created_at']

                        msg = f"Документ: {self.doc_table.item(selected, 1).text()}\nАвтор: {author}\nДата создания: {created_at}\n\nСтатус подписи: {'Подписан' if is_signed else 'Не подписан'}"
                        QMessageBox.information(self, "Проверка подписи", msg)
                    else:
                        QMessageBox.warning(self, "Ошибка", "Документ не найден")
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Ошибка проверки: {str(e)}")
            finally:
                if conn:
                    conn.close()
        else:
            QMessageBox.warning(self, "Ошибка", "Выберите документ")

    def show_document_details(self):
        # по двойному нажатию открываем заявки
        selected = self.doc_table.currentRow()
        if selected >= 0:
            doc_id = self.doc_table.item(selected, 0).text()

            details_dialog = QDialog(self)
            details_dialog.setWindowTitle(f"Детали документа ID {doc_id}")
            details_dialog.setModal(True)
            details_dialog.resize(800, 600)

            layout = QVBoxLayout()

            # таблица с заявками
            layout.addWidget(QLabel("Связанные заявки:"))
            request_table = QTableWidget()
            request_table.setColumnCount(4)
            request_table.setHorizontalHeaderLabels(["Заявка", "Отправитель", "Дата", "Комментарий"])
            request_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
            request_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
            request_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
            request_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)

            try:
                conn = get_db_connection()
                with conn.cursor() as cursor:
                    cursor.execute("""
                        SELECT r.id, CONCAT(u.first_name, ' ', COALESCE(u.last_name, ''), ' ', COALESCE(u.middle_name, '')) AS sender,
                               r.created_at, r.comment
                        FROM requests r
                        JOIN users u ON r.user_id = u.id
                        JOIN request_documents rd ON r.id = rd.request_id
                        WHERE rd.document_id = %s
                        ORDER BY r.created_at DESC
                    """, (doc_id,))
                    requests = cursor.fetchall()

                    request_table.setRowCount(len(requests))
                    for row, req in enumerate(requests):
                        for col, value in enumerate([
                            str(req['id']),
                            req['sender'].strip(),
                            str(req['created_at']),
                            req['comment'] or ""
                        ]):
                            item = QTableWidgetItem(value)
                            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                            request_table.setItem(row, col, item)

            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить заявки: {str(e)}")
            finally:
                if conn:
                    conn.close()

            # таблица с сообщениями
            layout.addWidget(QLabel("Сообщения по заявкам:"))
            message_table = QTableWidget()
            message_table.setColumnCount(4)
            message_table.setHorizontalHeaderLabels(["ID", "Отправитель", "Сообщение", "Дата"])
            message_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
            message_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
            message_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
            message_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)

            try:
                conn = get_db_connection()
                with conn.cursor() as cursor:
                    cursor.execute("""
                        SELECT m.id, CONCAT(u.first_name, ' ', COALESCE(u.last_name, ''), ' ', COALESCE(u.middle_name, '')) AS sender,
                               m.message, m.created_at
                        FROM messages m
                        JOIN users u ON m.sender_id = u.id
                        JOIN request_documents rd ON m.request_id = rd.request_id
                        WHERE rd.document_id = %s
                        ORDER BY m.created_at DESC
                    """, (doc_id,))
                    messages = cursor.fetchall()

                    message_table.setRowCount(len(messages))
                    for row, msg in enumerate(messages):
                        for col, value in enumerate([
                            str(msg['id']),
                            msg['sender'].strip(),
                            msg['message'],
                            str(msg['created_at'])
                        ]):
                            item = QTableWidgetItem(value)
                            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                            message_table.setItem(row, col, item)

            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить сообщения: {str(e)}")
            finally:
                if conn:
                    conn.close()

            layout.addWidget(message_table)

            # Поле для отправки сообщения
            layout.addWidget(QLabel("Новое сообщение:"))
            message_input = QTextEdit()
            message_input.setPlaceholderText("Введите сообщение...")
            message_input.setFixedHeight(50)
            layout.addWidget(message_input)

            send_message_btn = QPushButton("Отправить сообщение")
            def send_message():
                message = message_input.toPlainText().strip()
                if not message:
                    QMessageBox.warning(details_dialog, "Ошибка", "Введите текст сообщения")
                    return

                if not requests:
                    QMessageBox.warning(details_dialog, "Ошибка", "Нет связанных заявок для отправки сообщения")
                    return

                request_id = requests[0]['id']  # Берём ID первой заявки

                # Отправка сообщения и обновление таблицы в одной транзакции
                try:
                    conn = get_db_connection()
                    with conn.cursor() as cursor:
                        # Вставляем новое сообщение
                        cursor.execute("""
                            INSERT INTO messages (request_id, sender_id, message, created_at)
                            VALUES (%s, %s, %s, NOW())
                        """, (request_id, self.user_data['id'], message))
                        conn.commit()

                        # Обновляем таблицу сообщений
                        cursor.execute("""
                            SELECT m.id, CONCAT(u.first_name, ' ', COALESCE(u.last_name, ''), ' ', COALESCE(u.middle_name, '')) AS sender,
                                   m.message, m.created_at
                            FROM messages m
                            JOIN users u ON m.sender_id = u.id
                            JOIN request_documents rd ON m.request_id = rd.request_id
                            WHERE rd.document_id = %s
                            ORDER BY m.created_at DESC
                        """, (doc_id,))
                        messages = cursor.fetchall()

                        message_table.setRowCount(len(messages))
                        for row, msg in enumerate(messages):
                            for col, value in enumerate([
                                str(msg['id']),
                                msg['sender'].strip(),
                                msg['message'],
                                str(msg['created_at'])
                            ]):
                                item = QTableWidgetItem(value)
                                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                                message_table.setItem(row, col, item)

                        QMessageBox.information(details_dialog, "Успех", "Сообщение отправлено")
                        message_input.clear()

                except Exception as e:
                    QMessageBox.critical(details_dialog, "Ошибка", f"Не удалось отправить сообщение: {str(e)}")
                finally:
                    if conn:
                        conn.close()

            send_message_btn.clicked.connect(send_message)
            layout.addWidget(send_message_btn)

            # Кнопки действий
            buttons = QHBoxLayout()
            confirm_btn = QPushButton("Подтвердить")
            confirm_btn.clicked.connect(lambda: self.document_action("confirm", doc_id, details_dialog))
            buttons.addWidget(confirm_btn)

            reject_btn = QPushButton("Отказать")
            reject_btn.clicked.connect(lambda: self.document_action("reject", doc_id, details_dialog))
            buttons.addWidget(reject_btn)

            save_btn = QPushButton("Сохранить")
            save_btn.clicked.connect(lambda: self.document_action("save", doc_id, details_dialog))
            buttons.addWidget(save_btn)

            back_btn = QPushButton("Назад")
            back_btn.clicked.connect(details_dialog.close)
            buttons.addWidget(back_btn)

            layout.addLayout(buttons)
            details_dialog.setLayout(layout)
            details_dialog.exec()

    def document_action(self, action, doc_id, dialog):
        # добавляем действия с документом
        actions = {
            "confirm": ("подтвержден", 3),  # approved
            "reject": ("отклонен", 4),      # rejected
            "save": ("сохранен", 1)         # draft
        }
        if action in actions:
            action_text, status_id = actions[action]
            try:
                conn = get_db_connection()
                with conn.cursor() as cursor:
                    cursor.execute("""
                        UPDATE documents SET status_id = %s WHERE id = %s
                    """, (status_id, doc_id))
                    conn.commit()
                QMessageBox.information(self, action.capitalize(), f"Документ ID {doc_id} {action_text}")
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось выполнить действие: {str(e)}")
            finally:
                if conn:
                    conn.close()
        dialog.close()
        self.load_documents()

    def back_to_login(self):
        # возврат на авторизациь
        self.login_dialog.show()
        self.close()