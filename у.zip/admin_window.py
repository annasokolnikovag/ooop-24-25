from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
QPushButton, QMessageBox, QDialog, QFormLayout, QLineEdit, QComboBox, QInputDialog)
from database import get_db_connection

class AdminWindow(QMainWindow):
    def __init__(self, user_data, login_dialog):
        super().__init__()
        self.user_data = user_data
        self.login_dialog = login_dialog
        self.setWindowTitle(f"Панель администратора")
        self.setGeometry(100, 100, 900, 600)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        self.main_layout = QVBoxLayout()
        self.central_widget.setLayout(self.main_layout)
        self.init_ui()

    def init_ui(self):
        # инициализация интерфейса
        # страницы
        self.users_page = QWidget()
        self.documents_page = QWidget()

        self.init_users_page()
        self.init_documents_page()
        self.show_users_page()

    def init_users_page(self):
        # страница пользователя
        layout = QVBoxLayout()
        self.users_page.setLayout(layout)

        btn_layout = QHBoxLayout()
        self.add_user_btn = QPushButton("Добавить пользователя")
        self.add_user_btn.clicked.connect(self.show_add_user_dialog)
        btn_layout.addWidget(self.add_user_btn)
        self.view_docs_btn = QPushButton("Просмотр документов")
        self.view_docs_btn.clicked.connect(self.show_documents_page)
        btn_layout.addWidget(self.view_docs_btn)
        self.back_to_login_btn = QPushButton("Выйти из системы")
        self.back_to_login_btn.clicked.connect(self.back_to_login)
        btn_layout.addWidget(self.back_to_login_btn)
        layout.addLayout(btn_layout)

        self.users_table = QTableWidget()
        self.users_table.setColumnCount(5)
        self.users_table.setHorizontalHeaderLabels(["ID", "Логин", "Имя", "Фамилия", "Отчество", "Роль", "Подразделение"])
        self.users_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.users_table)

    def init_documents_page(self):
        # страница с документами
        layout = QVBoxLayout()
        self.documents_page.setLayout(layout)

        self.back_btn = QPushButton("Назад к пользователям")
        self.back_btn.clicked.connect(self.show_users_page)
        layout.addWidget(self.back_btn)
        self.docs_table = QTableWidget()
        self.docs_table.setColumnCount(5)
        self.docs_table.setHorizontalHeaderLabels(["ID", "Название", "Тип", "Статус", "Автор"])
        self.docs_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.docs_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        layout.addWidget(self.docs_table)
        btn_layout = QHBoxLayout()

        self.change_status_btn = QPushButton("Изменить статус")
        self.change_status_btn.clicked.connect(self.change_document_status)
        btn_layout.addWidget(self.change_status_btn)
        self.change_type_btn = QPushButton("Изменить тип")
        self.change_type_btn.clicked.connect(self.change_document_type)
        btn_layout.addWidget(self.change_type_btn)
        self.delete_btn = QPushButton("Удалить")
        self.delete_btn.clicked.connect(self.delete_document)
        btn_layout.addWidget(self.delete_btn)

        layout.addLayout(btn_layout)

    def show_users_page(self):
        # страница пользователя
        self.load_users()
        self.clear_layout()
        self.main_layout.addWidget(self.users_page)

    def show_documents_page(self):
        # страница документов
        self.load_documents()
        self.clear_layout()
        self.main_layout.addWidget(self.documents_page)

    def clear_layout(self):
        # очищаем экран
        while self.main_layout.count():
            item = self.main_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.setParent(None)

    def back_to_login(self):
        # возврат на авторизацию
        self.login_dialog.show()
        self.close()

    def load_users(self):
        # загружаем пользователем из бд
        try:
            conn = get_db_connection()
            with conn.cursor() as cursor:
                sql = """
                    SELECT id, login, first_name, last_name, middle_name, role, department 
                    FROM users
                """
                cursor.execute(sql)
                users = cursor.fetchall()

                self.users_table.setRowCount(len(users))
                for row, user in enumerate(users):
                    self.users_table.setItem(row, 0, QTableWidgetItem(str(user['id'])))
                    self.users_table.setItem(row, 1, QTableWidgetItem(user['login']))
                    self.users_table.setItem(row, 2, QTableWidgetItem(user['first_name'] or ''))
                    self.users_table.setItem(row, 3, QTableWidgetItem(user['last_name'] or ''))
                    self.users_table.setItem(row, 4, QTableWidgetItem(user['middle_name'] or ''))
                    self.users_table.setItem(row, 5, QTableWidgetItem(user['role']))
                    self.users_table.setItem(row, 6, QTableWidgetItem(user.get('department', '')))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить пользователей: {str(e)}")
        finally:
            if conn:
                conn.close()

    def load_documents(self):
        # загружаем документы
        try:
            conn = get_db_connection()
            with conn.cursor() as cursor:
                sql = """
                    SELECT d.id, d.title, dt.description AS type, ds.description AS status, 
                           CONCAT(u.first_name, ' ', COALESCE(u.last_name, ''), ' ', COALESCE(u.middle_name, '')) AS author
                    FROM documents d
                    JOIN users u ON d.user_id = u.id
                    JOIN document_types dt ON d.type_id = dt.id
                    JOIN document_statuses ds ON d.status_id = ds.id
                """
                cursor.execute(sql)
                docs = cursor.fetchall()

                self.docs_table.setRowCount(len(docs))
                for row, doc in enumerate(docs):
                    self.docs_table.setItem(row, 0, QTableWidgetItem(str(doc['id'])))
                    self.docs_table.setItem(row, 1, QTableWidgetItem(doc['title']))
                    self.docs_table.setItem(row, 2, QTableWidgetItem(doc['type']))
                    self.docs_table.setItem(row, 3, QTableWidgetItem(doc['status']))
                    self.docs_table.setItem(row, 4, QTableWidgetItem(doc['author'].strip()))
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить документы: {str(e)}")
        finally:
            if conn:
                conn.close()

    def show_add_user_dialog(self):
        # добавляем пользователя
        dialog = QDialog(self)
        dialog.setWindowTitle("Добавить пользователя")
        dialog.setFixedSize(300, 300)

        layout = QFormLayout()

        self.login_input = QLineEdit()
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.first_name_input = QLineEdit()
        self.last_name_input = QLineEdit()
        self.middle_name_input = QLineEdit()
        self.role_combo = QComboBox()
        self.role_combo.addItems(["user", "moderator", "admin"])
        self.department_input = QLineEdit()
        layout.addRow("Логин:", self.login_input)
        layout.addRow("Пароль:", self.password_input)
        layout.addRow("Имя:", self.first_name_input)
        layout.addRow("Фамилия:", self.last_name_input)
        layout.addRow("Отчество:", self.middle_name_input)
        layout.addRow("Роль:", self.role_combo)
        layout.addRow("Подразделение:", self.department_input)

        btn_layout = QHBoxLayout()
        save_btn = QPushButton("Сохранить")
        save_btn.clicked.connect(lambda: self.save_user(dialog))
        btn_layout.addWidget(save_btn)
        cancel_btn = QPushButton("Отмена")
        cancel_btn.clicked.connect(dialog.reject)
        btn_layout.addWidget(cancel_btn)
        layout.addRow(btn_layout)
        dialog.setLayout(layout)
        dialog.exec()

    def save_user(self, dialog):
        # сохранение
        login = self.login_input.text()
        password = self.password_input.text()
        first_name = self.first_name_input.text()
        last_name = self.last_name_input.text()
        middle_name = self.middle_name_input.text()
        role = self.role_combo.currentText()
        department = self.department_input.text()

        if not login or not password:
            QMessageBox.warning(self, "Ошибка", "Заполните обязательные поля")
            return

        try:
            conn = get_db_connection()
            with conn.cursor() as cursor:
                sql = """
                    INSERT INTO users (login, password, first_name, last_name, middle_name, role, department) 
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql, (login, password, first_name or None, last_name or None, middle_name or None, role, department or None))
                conn.commit()
                self.load_users()
                dialog.accept()
                QMessageBox.information(self, "Успех", "Пользователь добавлен")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка: {str(e)}")
        finally:
            if conn:
                conn.close()
            self.login_input.clear()
            self.password_input.clear()
            self.first_name_input.clear()
            self.last_name_input.clear()
            self.middle_name_input.clear()
            self.department_input.clear()

    def change_document_status(self):
        # кнопка изменения
        selected = self.docs_table.currentRow()
        if selected >= 0:
            doc_id = self.docs_table.item(selected, 0).text()
            status, ok = QInputDialog.getItem(
                self, "Изменить статус", "Выберите новый статус:",
                ["Черновик", "На рассмотрении", "Утвержден", "Отклонен"], 0, False
            )
            if ok and status:
                status_map = {
                    "Черновик": 1,
                    "На рассмотрении": 2,
                    "Утвержден": 3,
                    "Отклонен": 4
                }
                status_id = status_map.get(status)
                try:
                    conn = get_db_connection()
                    with conn.cursor() as cursor:
                        sql = "UPDATE documents SET status_id = %s WHERE id = %s"
                        cursor.execute(sql, (status_id, doc_id))
                        conn.commit()
                        self.load_documents()
                        QMessageBox.information(self, "Успех", "Статус обновлен")
                except Exception as e:
                    QMessageBox.critical(self, "Ошибка", f"Не удалось изменить статус: {str(e)}")
                finally:
                    if conn:
                        conn.close()
        else:
            QMessageBox.warning(self, "Ошибка", "Выберите документ")

    def change_document_type(self):
        # кнопка изменения
        selected = self.docs_table.currentRow()
        if selected >= 0:
            doc_id = self.docs_table.item(selected, 0).text()
            doc_type, ok = QInputDialog.getItem(
                self, "Изменить тип", "Выберите новый тип документа:",
                ["Excel-документ", "Word-документ"], 0, False
            )
            if ok and doc_type:
                type_map = {
                    "Excel-документ": 1,
                    "Word-документ": 2
                }
                type_id = type_map.get(doc_type)
                try:
                    conn = get_db_connection()
                    with conn.cursor() as cursor:
                        sql = "UPDATE documents SET type_id = %s WHERE id = %s"
                        cursor.execute(sql, (type_id, doc_id))
                        conn.commit()
                        self.load_documents()
                        QMessageBox.information(self, "Успех", "Тип обновлен")
                except Exception as e:
                    QMessageBox.critical(self, "Ошибка", f"Не удалось изменить тип: {str(e)}")
                finally:
                    if conn:
                        conn.close()
        else:
            QMessageBox.warning(self, "Ошибка", "Выберите документ")

    def delete_document(self):
        # кнопка удаления
        selected = self.docs_table.currentRow()
        if selected >= 0:
            doc_id = self.docs_table.item(selected, 0).text()
            reply = QMessageBox.question(
                self, "Подтверждение",
                "Вы уверены, что хотите удалить этот документ?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.Yes:
                try:
                    conn = get_db_connection()
                    with conn.cursor() as cursor:
                        sql = "DELETE FROM documents WHERE id = %s"
                        cursor.execute(sql, (doc_id,))
                        conn.commit()
                        self.load_documents()
                        QMessageBox.information(self, "Успех", "Документ удален")
                except Exception as e:
                    QMessageBox.critical(self, "Ошибка", f"Не удалось удалить документ: {str(e)}")
                finally:
                    if conn:
                        conn.close()
        else:
            QMessageBox.warning(self, "Ошибка", "Выберите документ")