from PyQt6.QtWidgets import QApplication, QDialog
from login_dialog import LoginDialog
from user_window import UserWindow
from admin_window import AdminWindow
import sys

if __name__ == '__main__':
    app = QApplication(sys.argv)
    login_dialog = LoginDialog()
    if login_dialog.exec() == QDialog.DialogCode.Accepted:
        user_data = login_dialog.user_data
        # в зависимости от роли пользователя открываем окно
        if user_data['role'] == 'user':
            window = UserWindow(user_data, login_dialog)
        else:
            window = AdminWindow(user_data, login_dialog)
        window.show()
        sys.exit(app.exec())