from PyQt6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox
from database import get_db_connection

class LoginDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Авторизация")
        self.setGeometry(300, 300, 300, 200)

        self.layout = QVBoxLayout()

        self.login_label = QLabel("Логин:")
        self.login_input = QLineEdit()
        self.layout.addWidget(self.login_label)
        self.layout.addWidget(self.login_input)
        self.password_label = QLabel("Пароль:")
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.layout.addWidget(self.password_label)
        self.layout.addWidget(self.password_input)

        buttons_layout = QHBoxLayout()
        self.login_btn = QPushButton("Войти")
        self.login_btn.clicked.connect(self.check_credentials)
        buttons_layout.addWidget(self.login_btn)
        self.cancel_btn = QPushButton("Отмена")
        self.cancel_btn.clicked.connect(self.reject)
        buttons_layout.addWidget(self.cancel_btn)
        self.layout.addLayout(buttons_layout)
        self.setLayout(self.layout)

    def check_credentials(self):
        # метод проверки данных
        login = self.login_input.text().strip()
        password = self.password_input.text().strip()

        try:
            conn = get_db_connection()
            with conn.cursor() as cursor:
                cursor.execute("""
                    SELECT id, CONCAT(first_name, ' ', COALESCE(last_name, ''), ' ', COALESCE(middle_name, '')) AS full_name, role
                    FROM users 
                    WHERE login = %s AND password = %s
                """, (login, password))
                user = cursor.fetchone()

                if user:
                    self.user_data = {
                        'id': user['id'],
                        'full_name': user['full_name'].strip(),  # Конкатенированное имя
                        'role': user['role']
                    }
                    self.accept()
                else:
                    QMessageBox.critical(self, "Ошибка", "Неверный логин или пароль")

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка подключения: {str(e)}")
        finally:
            if conn:
                conn.close()