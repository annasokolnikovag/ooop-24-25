from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
QPushButton, QLineEdit, QMessageBox, QLabel, QComboBox, QHeaderView, QStackedWidget, QAbstractItemView, QTextEdit, QDialog)
from PyQt6.QtCore import Qt
from database import get_db_connection

class AdminWindow(QMainWindow):
    def __init__(self, user_data, login_dialog):
        super().__init__()
        self.user_data = user_data
        self.login_dialog = login_dialog
        self.setWindowTitle(f"Админ")
        self.setGeometry(100, 100, 900, 500)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)

        self.stacked_widget = QStackedWidget()
        self.central_widget.setLayout(QVBoxLayout())
        self.central_widget.layout().addWidget(self.stacked_widget)

        # страница пользователи
        self.users_page = QWidget()
        self.users_layout = QVBoxLayout()
        self.users_page.setLayout(self.users_layout)
        self.create_users_page()
        self.stacked_widget.addWidget(self.users_page)

        # страница заявок
        self.requests_page = QWidget()
        self.requests_layout = QVBoxLayout()
        self.requests_page.setLayout(self.requests_layout)
        self.create_requests_page()
        self.stacked_widget.addWidget(self.requests_page)

        # начальная страница пользователи
        self.stacked_widget.setCurrentWidget(self.users_page)

    def create_users_page(self):
        # страница пользователей
        top_layout = QHBoxLayout()

        buttons_layout = QHBoxLayout()
        self.back_btn = QPushButton("Назад")
        self.back_btn.clicked.connect(self.back_to_login)
        buttons_layout.addWidget(self.back_btn)
        self.add_user_btn = QPushButton("Добавить пользователя")
        self.add_user_btn.clicked.connect(self.add_user)
        buttons_layout.addWidget(self.add_user_btn)
        self.show_requests_btn = QPushButton("Заявки")
        self.show_requests_btn.clicked.connect(self.show_requests)
        buttons_layout.addWidget(self.show_requests_btn)
        top_layout.addLayout(buttons_layout)

        self.users_layout.addLayout(top_layout)
        # таблица пользователей
        self.user_table = QTableWidget()
        self.user_table.setColumnCount(5)
        self.user_table.setHorizontalHeaderLabels(["ID", "Логин", "Имя", "Фамилия", "Отчество", "Роль"])
        self.user_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.user_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.user_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.user_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.users_layout.addWidget(QLabel("Пользователи:"))
        self.users_layout.addWidget(self.user_table)
        self.load_users()

    def create_requests_page(self):
        # страница заявок
        top_layout = QHBoxLayout()
        buttons_layout = QHBoxLayout()
        self.back_to_users_btn = QPushButton("Назад")
        self.back_to_users_btn.clicked.connect(self.show_users)
        buttons_layout.addWidget(self.back_to_users_btn)
        top_layout.addLayout(buttons_layout)

        # поиск
        search_layout = QHBoxLayout()
        search_layout.addWidget(QLabel("Поиск по ID заявки:"))
        self.requests_search_input = QLineEdit()
        self.requests_search_input.setPlaceholderText("Введите ID заявки")
        search_layout.addWidget(self.requests_search_input)

        self.search_btn = QPushButton("Найти")
        self.search_btn.clicked.connect(self.search_requests)
        search_layout.addWidget(self.search_btn)
        top_layout.addLayout(search_layout)
        self.requests_layout.addLayout(top_layout)

        # фильтрация по почте
        filter_layout = QHBoxLayout()
        filter_layout.addWidget(QLabel("Фильтр по email:"))
        self.email_filter = QComboBox()
        self.email_filter.addItems(["Все", "По email", "Не по email"])
        self.email_filter.currentTextChanged.connect(self.load_requests)
        filter_layout.addWidget(self.email_filter)
        self.requests_layout.addLayout(filter_layout)

        # таблица заявок
        self.request_table = QTableWidget()
        self.request_table.setColumnCount(7)
        self.request_table.setHorizontalHeaderLabels(["ID", "Клиент", "Тип", "Статус", "Приоритет", "Комментарий", "Дата"])
        self.request_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.request_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.request_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.request_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.requests_layout.addWidget(QLabel("Заявки:"))
        self.requests_layout.addWidget(self.request_table)

        buttons_layout = QHBoxLayout()
        self.assign_btn = QPushButton("Изменить распределение")
        self.assign_btn.clicked.connect(self.assign_request)
        buttons_layout.addWidget(self.assign_btn)
        self.change_status_btn = QPushButton("Изменить статус")
        self.change_status_btn.clicked.connect(self.change_status)
        buttons_layout.addWidget(self.change_status_btn)
        self.change_priority_btn = QPushButton("Изменить приоритет")
        self.change_priority_btn.clicked.connect(self.change_priority)
        buttons_layout.addWidget(self.change_priority_btn)
        self.change_type_btn = QPushButton("Изменить тип")
        self.change_type_btn.clicked.connect(self.change_type)
        buttons_layout.addWidget(self.change_type_btn)
        self.delete_request_btn = QPushButton("Удалить заявку")
        self.delete_request_btn.clicked.connect(self.delete_request)
        buttons_layout.addWidget(self.delete_request_btn)
        self.requests_layout.addLayout(buttons_layout)

        self.load_requests()

    def load_users(self):
        # загружаем пользователей
        try:
            conn = get_db_connection()
            with conn.cursor() as cursor:
                cursor.execute("""
                    SELECT id, login, first_name, last_name, middle_name, role 
                    FROM users 
                    ORDER BY id
                """)
                users = cursor.fetchall()
                self.user_table.setRowCount(len(users))
                for row, user in enumerate(users):
                    for col, value in enumerate([
                        str(user['id']),
                        user['login'],
                        user['first_name'] or "",
                        user['last_name'] or "",
                        user['middle_name'] or "",
                        "Админ" if user['role'] == 'admin' else "Пользователь"
                    ]):
                        item = QTableWidgetItem(value)
                        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                        self.user_table.setItem(row, col, item)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить пользователей: {str(e)}")
        finally:
            if conn:
                conn.close()

    def load_requests(self):
        # загружаем заявки
        try:
            conn = get_db_connection()
            with conn.cursor() as cursor:
                query = """
                    SELECT r.id, CONCAT(u.first_name, ' ', COALESCE(u.last_name, ''), ' ', COALESCE(u.middle_name, '')) AS client_name,
                           rt.description AS type, rs.description AS status, rp.description AS priority, 
                           r.comment, r.created_at
                    FROM requests r
                    JOIN users u ON r.user_id = u.id
                    JOIN request_types rt ON r.type_id = rt.id
                    JOIN request_statuses rs ON r.status_id = rs.id
                    JOIN request_priorities rp ON r.priority_id = rp.id
                    WHERE 1=1
                """
                params = []
                # применяем фильтр по почте
                filter_text = self.email_filter.currentText()
                if filter_text == "По email":
                    query += " AND r.email_request = TRUE"
                elif filter_text == "Не по email":
                    query += " AND r.email_request = FALSE"
                query += " ORDER BY r.created_at DESC"
                cursor.execute(query, params)
                requests = cursor.fetchall()

                self.request_table.setRowCount(len(requests))
                for row, req in enumerate(requests):
                    for col, value in enumerate([
                        str(req['id']),
                        req['client_name'].strip(),
                        req['type'],
                        req['status'],
                        req['priority'],
                        req['comment'] or "",
                        str(req['created_at'])
                    ]):
                        item = QTableWidgetItem(value)
                        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                        self.request_table.setItem(row, col, item)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить заявки: {str(e)}")
        finally:
            if conn:
                conn.close()

    def show_users(self):
        self.stacked_widget.setCurrentWidget(self.users_page)

    def show_requests(self):
        self.stacked_widget.setCurrentWidget(self.requests_page)

    def add_user(self):
        # кнопка добавить пользователя
        dialog = QDialog(self)
        dialog.setWindowTitle("Добавить пользователя")
        dialog.setModal(True)
        dialog.resize(400, 400)

        layout = QVBoxLayout()
        login_label = QLabel("Логин:")
        login_input = QLineEdit()
        layout.addWidget(login_label)
        layout.addWidget(login_input)
        password_label = QLabel("Пароль:")
        password_input = QLineEdit()
        password_input.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addWidget(password_label)
        layout.addWidget(password_input)
        first_name_label = QLabel("Имя:")
        first_name_input = QLineEdit()
        layout.addWidget(first_name_label)
        layout.addWidget(first_name_input)
        last_name_label = QLabel("Фамилия:")
        last_name_input = QLineEdit()
        layout.addWidget(last_name_label)
        layout.addWidget(last_name_input)
        middle_name_label = QLabel("Отчество:")
        middle_name_input = QLineEdit()
        layout.addWidget(middle_name_label)
        layout.addWidget(middle_name_input)
        role_label = QLabel("Роль:")
        role_combo = QComboBox()
        role_combo.addItems(["Пользователь", "Админ"])
        layout.addWidget(role_label)
        layout.addWidget(role_combo)

        buttons = QHBoxLayout()
        submit_btn = QPushButton("Добавить")
        def submit_user():
            login = login_input.text().strip()
            password = password_input.text().strip()
            first_name = first_name_input.text().strip()
            last_name = last_name_input.text().strip()
            middle_name = middle_name_input.text().strip()
            role = 'admin' if role_combo.currentText() == "Админ" else 'user'

            if not login or not password:
                QMessageBox.warning(dialog, "Ошибка", "Введите логин и пароль")
                return

            try:
                conn = get_db_connection()
                with conn.cursor() as cursor:
                    cursor.execute("""
                        INSERT INTO users (login, password, first_name, last_name, middle_name, role)
                        VALUES (%s, %s, %s, %s, %s, %s)
                    """, (login, password, first_name or None, last_name or None, middle_name or None, role))
                    conn.commit()
                QMessageBox.information(dialog, "Успех", "Пользователь добавлен")
                dialog.accept()
                self.load_users()
            except Exception as e:
                QMessageBox.critical(dialog, "Ошибка", f"Не удалось добавить пользователя: {str(e)}")
            finally:
                if conn:
                    conn.close()

        submit_btn.clicked.connect(submit_user)
        buttons.addWidget(submit_btn)

        cancel_btn = QPushButton("Отмена")
        cancel_btn.clicked.connect(dialog.reject)
        buttons.addWidget(cancel_btn)

        layout.addLayout(buttons)
        dialog.setLayout(layout)
        dialog.exec()

    def assign_request(self):
        # распределение по заявкам
        selected = self.request_table.currentRow()
        if selected >= 0:
            request_id = self.request_table.item(selected, 0).text()

            dialog = QDialog(self)
            dialog.setWindowTitle(f"Распределение заявки #{request_id}")
            dialog.setModal(True)
            dialog.resize(400, 200)

            layout = QVBoxLayout()

            operator_label = QLabel("Оператор:")
            operator_combo = QComboBox()
            operator_combo.addItem("Не назначен")
            layout.addWidget(operator_label)
            layout.addWidget(operator_combo)

            observer_label = QLabel("Наблюдатель:")
            observer_combo = QComboBox()
            observer_combo.addItem("Не назначен")
            layout.addWidget(observer_label)
            layout.addWidget(observer_combo)

            try:
                conn = get_db_connection()
                with conn.cursor() as cursor:
                    cursor.execute("""
                        SELECT id, CONCAT(first_name, ' ', COALESCE(last_name, ''), ' ', COALESCE(middle_name, '')) AS name
                        FROM users 
                        WHERE role = 'admin'
                    """)
                    admins = cursor.fetchall()
                    for admin in admins:
                        operator_combo.addItem(admin['name'].strip(), admin['id'])
                        observer_combo.addItem(admin['name'].strip(), admin['id'])

                    cursor.execute("""
                        SELECT operator_id, observer_id
                        FROM request_assignments
                        WHERE request_id = %s
                        LIMIT 1
                    """, (request_id,))
                    assignment = cursor.fetchone()
                    if assignment:
                        if assignment['operator_id']:
                            for i in range(operator_combo.count()):
                                if operator_combo.itemData(i) == assignment['operator_id']:
                                    operator_combo.setCurrentIndex(i)
                                    break
                        if assignment['observer_id']:
                            for i in range(observer_combo.count()):
                                if observer_combo.itemData(i) == assignment['observer_id']:
                                    observer_combo.setCurrentIndex(i)
                                    break
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить данные: {str(e)}")
                return
            finally:
                if conn:
                    conn.close()

            buttons = QHBoxLayout()
            submit_btn = QPushButton("Сохранить")
            def submit_assignment():
                operator_id = operator_combo.currentData() if operator_combo.currentIndex() > 0 else None
                observer_id = observer_combo.currentData() if operator_combo.currentIndex() > 0 else None
                try:
                    conn = get_db_connection()
                    with conn.cursor() as cursor:
                        cursor.execute("""
                            INSERT INTO request_assignments (request_id, operator_id, observer_id, created_at)
                            VALUES (%s, %s, %s, NOW())
                            ON DUPLICATE KEY UPDATE
                            operator_id = VALUES(operator_id),
                            observer_id = VALUES(observer_id)
                        """, (request_id, operator_id, observer_id))
                        conn.commit()
                    QMessageBox.information(dialog, "Успех", "Распределение обновлено")
                    dialog.accept()
                    self.load_requests()
                except Exception as e:
                    QMessageBox.critical(dialog, "Ошибка", f"Не удалось обновить распределение: {str(e)}")
                finally:
                    if conn:
                        conn.close()

            submit_btn.clicked.connect(submit_assignment)
            buttons.addWidget(submit_btn)

            cancel_btn = QPushButton("Отмена")
            cancel_btn.clicked.connect(dialog.reject)
            buttons.addWidget(cancel_btn)

            layout.addLayout(buttons)
            dialog.setLayout(layout)
            dialog.exec()
        else:
            QMessageBox.warning(self, "Ошибка", "Выберите заявку")

    def change_status(self):
        # меняем статус
        selected = self.request_table.currentRow()
        if selected >= 0:
            request_id = self.request_table.item(selected, 0).text()

            dialog = QDialog(self)
            dialog.setWindowTitle(f"Изменить статус заявки #{request_id}")
            dialog.setModal(True)
            dialog.resize(300, 150)

            layout = QVBoxLayout()

            status_combo = QComboBox()
            status_combo.addItems(["Новая", "В процессе", "Завершена", "Отклонена"])
            layout.addWidget(QLabel("Новый статус:"))
            layout.addWidget(status_combo)

            buttons = QHBoxLayout()
            submit_btn = QPushButton("Сохранить")
            def submit_status():
                status_map = {
                    "Новая": 1,
                    "В процессе": 2,
                    "Завершена": 3,
                    "Отклонена": 4
                }
                new_status_id = status_map.get(status_combo.currentText())
                try:
                    conn = get_db_connection()
                    with conn.cursor() as cursor:
                        cursor.execute("""
                            UPDATE requests SET status_id = %s WHERE id = %s
                        """, (new_status_id, request_id))
                        conn.commit()
                    QMessageBox.information(dialog, "Успех", "Статус обновлен")
                    dialog.accept()
                    self.load_requests()
                except Exception as e:
                    QMessageBox.critical(dialog, "Ошибка", f"Не удалось обновить статус: {str(e)}")
                finally:
                    if conn:
                        conn.close()

            submit_btn.clicked.connect(submit_status)
            buttons.addWidget(submit_btn)

            cancel_btn = QPushButton("Отмена")
            cancel_btn.clicked.connect(dialog.reject)
            buttons.addWidget(cancel_btn)

            layout.addLayout(buttons)
            dialog.setLayout(layout)
            dialog.exec()
        else:
            QMessageBox.warning(self, "Ошибка", "Выберите заявку")

    def change_priority(self):
        # меняем приоритет
        selected = self.request_table.currentRow()
        if selected >= 0:
            request_id = self.request_table.item(selected, 0).text()

            dialog = QDialog(self)
            dialog.setWindowTitle(f"Изменить приоритет заявки #{request_id}")
            dialog.setModal(True)
            dialog.resize(300, 150)

            layout = QVBoxLayout()

            priority_combo = QComboBox()
            priority_combo.addItems(["Низкий", "Средний", "Высокий"])
            layout.addWidget(QLabel("Новый приоритет:"))
            layout.addWidget(priority_combo)

            buttons = QHBoxLayout()
            submit_btn = QPushButton("Сохранить")
            def submit_priority():
                priority_map = {
                    "Низкий": 1,
                    "Средний": 2,
                    "Высокий": 3
                }
                new_priority_id = priority_map.get(priority_combo.currentText())

                try:
                    conn = get_db_connection()
                    with conn.cursor() as cursor:
                        cursor.execute("""
                            UPDATE requests SET priority_id = %s WHERE id = %s
                        """, (new_priority_id, request_id))
                        conn.commit()
                    QMessageBox.information(dialog, "Успех", "Приоритет обновлен")
                    dialog.accept()
                    self.load_requests()
                except Exception as e:
                    QMessageBox.critical(dialog, "Ошибка", f"Не удалось обновить приоритет: {str(e)}")
                finally:
                    if conn:
                        conn.close()

            submit_btn.clicked.connect(submit_priority)
            buttons.addWidget(submit_btn)

            cancel_btn = QPushButton("Отмена")
            cancel_btn.clicked.connect(dialog.reject)
            buttons.addWidget(cancel_btn)

            layout.addLayout(buttons)
            dialog.setLayout(layout)
            dialog.exec()
        else:
            QMessageBox.warning(self, "Ошибка", "Выберите заявку")

    def change_type(self):
        # меняем тип
        selected = self.request_table.currentRow()
        if selected >= 0:
            request_id = self.request_table.item(selected, 0).text()

            dialog = QDialog(self)
            dialog.setWindowTitle(f"Изменить тип заявки #{request_id}")
            dialog.setModal(True)
            dialog.resize(300, 150)

            layout = QVBoxLayout()

            type_combo = QComboBox()
            type_combo.addItems([
                "Разработка проекта", "Перепланировка", "Замена перекрытий",
                "Замена перегородок", "Усиление", "Замена коммуникаций",
                "Пусконаладочные работы", "Проверка систем", "Другое"
            ])
            layout.addWidget(QLabel("Новый тип:"))
            layout.addWidget(type_combo)

            buttons = QHBoxLayout()
            submit_btn = QPushButton("Сохранить")
            def submit_type():
                type_map = {
                    "Разработка проекта": 1,
                    "Перепланировка": 2,
                    "Замена перекрытий": 3,
                    "Замена перегородок": 4,
                    "Усиление": 5,
                    "Замена коммуникаций": 6,
                    "Пусконаладочные работы": 7,
                    "Проверка систем": 8,
                    "Другое": 9
                }
                new_type_id = type_map.get(type_combo.currentText())

                try:
                    conn = get_db_connection()
                    with conn.cursor() as cursor:
                        cursor.execute("""
                            UPDATE requests SET type_id = %s WHERE id = %s
                        """, (new_type_id, request_id))
                        conn.commit()
                    QMessageBox.information(dialog, "Успех", "Тип заявки обновлен")
                    dialog.accept()
                    self.load_requests()
                except Exception as e:
                    QMessageBox.critical(dialog, "Ошибка", f"Не удалось обновить тип: {str(e)}")
                finally:
                    if conn:
                        conn.close()

            submit_btn.clicked.connect(submit_type)
            buttons.addWidget(submit_btn)

            cancel_btn = QPushButton("Отмена")
            cancel_btn.clicked.connect(dialog.reject)
            buttons.addWidget(cancel_btn)

            layout.addLayout(buttons)
            dialog.setLayout(layout)
            dialog.exec()
        else:
            QMessageBox.warning(self, "Ошибка", "Выберите заявку")

    def delete_request(self):
        # кнопка удаления
        selected = self.request_table.currentRow()
        if selected >= 0:
            request_id = self.request_table.item(selected, 0).text()
            reply = QMessageBox.question(self, "Подтверждение",
                                         f"Вы уверены, что хотите удалить заявку #{request_id}?",
                                         QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if reply == QMessageBox.StandardButton.Yes:
                try:
                    conn = get_db_connection()
                    with conn.cursor() as cursor:
                        cursor.execute("DELETE FROM request_files WHERE request_id = %s", (request_id,))
                        cursor.execute("DELETE FROM request_assignments WHERE request_id = %s", (request_id,))
                        cursor.execute("DELETE FROM messages WHERE request_id = %s", (request_id,))
                        cursor.execute("DELETE FROM requests WHERE id = %s", (request_id,))
                        conn.commit()
                    QMessageBox.information(self, "Успех", f"Заявка #{request_id} удалена")
                    self.load_requests()
                except Exception as e:
                    QMessageBox.critical(self, "Ошибка", f"Не удалось удалить заявку: {str(e)}")
                finally:
                    if conn:
                        conn.close()
        else:
            QMessageBox.warning(self, "Ошибка", "Выберите заявку")

    def search_requests(self):
        # поиск
        search_id = self.requests_search_input.text().strip()
        if not search_id.isdigit():
            QMessageBox.warning(self, "Ошибка", "Введите корректный ID заявки")
            return
        try:
            conn = get_db_connection()
            with conn.cursor() as cursor:
                cursor.execute("""
                    SELECT r.id, CONCAT(u.first_name, ' ', COALESCE(u.last_name, ''), ' ', COALESCE(u.middle_name, '')) AS client_name,
                           rt.description AS type, rs.description AS status, rp.description AS priority, 
                           r.comment, r.created_at
                    FROM requests r
                    JOIN users u ON r.user_id = u.id
                    JOIN request_types rt ON r.type_id = rt.id
                    JOIN request_statuses rs ON r.status_id = rs.id
                    JOIN request_priorities rp ON r.priority_id = rp.id
                    WHERE r.id = %s
                """, (search_id,))
                req = cursor.fetchone()

                if req:
                    dialog = QDialog(self)
                    dialog.setWindowTitle(f"Заявка #{search_id}")
                    dialog.setModal(True)
                    dialog.resize(400, 300)

                    layout = QVBoxLayout()
                    details = QTextEdit()
                    details.setReadOnly(True)
                    details.setText(
                        f"ID: {req['id']}\n"
                        f"Клиент: {req['client_name'].strip()}\n"
                        f"Тип: {req['type']}\n"
                        f"Статус: {req['status']}\n"
                        f"Приоритет: {req['priority']}\n"
                        f"Комментарий: {req['comment'] or ''}\n"
                        f"Дата создания: {req['created_at']}"
                    )
                    layout.addWidget(details)

                    close_btn = QPushButton("Закрыть")
                    close_btn.clicked.connect(dialog.close)
                    layout.addWidget(close_btn)

                    dialog.setLayout(layout)
                    dialog.exec()
                else:
                    QMessageBox.warning(self, "Ошибка", "Заявка не найдена")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка поиска: {str(e)}")
        finally:
            if conn:
                conn.close()

    def back_to_login(self):
        # возвращаемся на авторизацию
        self.login_dialog.show()
        self.close()