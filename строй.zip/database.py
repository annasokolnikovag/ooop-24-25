import pymysql
from pymysql.cursors import DictCursor
# подключение к бд
def get_db_connection():
    return pymysql.connect(
        host='localhost',
        user='root',
        password='',
        database='construction_requests',
        charset='utf8mb4',
        use_unicode=True,
        cursorclass=DictCursor
    )