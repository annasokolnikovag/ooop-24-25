from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
 QPushButton, QFileDialog, QMessageBox, QLabel, QComboBox, QHeaderView, QDialog, QAbstractItemView, QTextEdit)
from PyQt6.QtCore import Qt
from database import get_db_connection
import os

class UserWindow(QMainWindow):
    def __init__(self, user_data, login_dialog):
        super().__init__()
        self.user_data = user_data
        self.login_dialog = login_dialog
        self.setWindowTitle(f"Заявки")
        self.setGeometry(100, 100, 900, 500)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.layout = QVBoxLayout()
        self.central_widget.setLayout(self.layout)

        # фильтрация по статусу
        self.create_filters_panel()
        self.create_buttons_panel()
        self.create_requests_table()

        self.load_requests()

    def create_filters_panel(self):
        # фильтрация по статусу
        filters_layout = QHBoxLayout()
        self.status_filter = QComboBox()
        self.status_filter.addItems(["Все статусы", "Новая", "В процессе", "Завершена", "Отклонена"])
        filters_layout.addWidget(QLabel("Статус:"))
        filters_layout.addWidget(self.status_filter)

        self.apply_filters_btn = QPushButton("Применить")
        self.apply_filters_btn.clicked.connect(self.apply_filters)
        filters_layout.addWidget(self.apply_filters_btn)

        self.layout.addLayout(filters_layout)


    def create_buttons_panel(self):
        # кнопки
        buttons_layout = QHBoxLayout()

        self.back_btn = QPushButton("Назад")
        self.back_btn.clicked.connect(self.back_to_login)
        buttons_layout.addWidget(self.back_btn)
        self.create_request_btn = QPushButton("Создать заявку")
        self.create_request_btn.clicked.connect(self.create_request)
        buttons_layout.addWidget(self.create_request_btn)
        self.check_status_btn = QPushButton("Показать статус")
        self.check_status_btn.clicked.connect(self.check_status)
        buttons_layout.addWidget(self.check_status_btn)

        self.layout.addLayout(buttons_layout)

    def create_requests_table(self):
        # таблица заявок
        self.request_table = QTableWidget()
        self.request_table.setColumnCount(6)
        self.request_table.setHorizontalHeaderLabels(["ID", "Тип", "Статус", "Приоритет", "Комментарий", "Дата"])
        self.request_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.request_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.request_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.request_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.request_table.doubleClicked.connect(self.show_request_details)
        self.layout.addWidget(self.request_table)

    def load_requests(self):
        # загружаем заявки
        try:
            conn = get_db_connection()
            with conn.cursor() as cursor:
                cursor.execute("""
                    SELECT r.id, rt.description AS type, rs.description AS status, rp.description AS priority, 
                           r.comment, r.created_at
                    FROM requests r
                    JOIN request_types rt ON r.type_id = rt.id
                    JOIN request_statuses rs ON r.status_id = rs.id
                    JOIN request_priorities rp ON r.priority_id = rp.id
                    WHERE r.user_id = %s
                    ORDER BY r.created_at DESC
                """, (self.user_data['id'],))
                requests = cursor.fetchall()

                self.request_table.setRowCount(len(requests))
                for row, req in enumerate(requests):
                    for col, value in enumerate([
                        str(req['id']),
                        req['type'],
                        req['status'],
                        req['priority'],
                        req['comment'] or "",
                        str(req['created_at'])
                    ]):
                        item = QTableWidgetItem(value)
                        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                        self.request_table.setItem(row, col, item)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить заявки: {str(e)}")
        finally:
            if conn:
                conn.close()

    def apply_filters(self):
        # кнопка фильтров
        try:
            conn = get_db_connection()
            with conn.cursor() as cursor:
                sql = """
                    SELECT r.id, rt.description AS type, rs.description AS status, rp.description AS priority, 
                           r.comment, r.created_at
                    FROM requests r
                    JOIN request_types rt ON r.type_id = rt.id
                    JOIN request_statuses rs ON r.status_id = rs.id
                    JOIN request_priorities rp ON r.priority_id = rp.id
                    WHERE r.user_id = %s
                """
                params = [self.user_data['id']]
                conditions = []

                status_map = {
                    "Новая": 1,
                    "В процессе": 2,
                    "Завершена": 3,
                    "Отклонена": 4
                }
                status_filter = self.status_filter.currentText()
                if status_filter != "Все статусы":
                    conditions.append("rs.id = %s")
                    params.append(status_map[status_filter])
                if conditions:
                    sql += " AND " + " AND ".join(conditions)
                sql += " ORDER BY r.created_at DESC"
                cursor.execute(sql, params)
                requests = cursor.fetchall()

                self.request_table.setRowCount(len(requests))
                for row, req in enumerate(requests):
                    for col, value in enumerate([
                        str(req['id']),
                        req['type'],
                        req['status'],
                        req['priority'],
                        req['comment'] or "",
                        str(req['created_at'])
                    ]):
                        item = QTableWidgetItem(value)
                        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                        self.request_table.setItem(row, col, item)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка фильтрации: {str(e)}")
        finally:
            if conn:
                conn.close()

    def create_request(self):
        # создаем заявку
        dialog = QDialog(self)
        dialog.setWindowTitle("Создать новую заявку")
        dialog.setModal(True)
        dialog.resize(600, 400)

        layout = QVBoxLayout()
        type_layout = QHBoxLayout()
        type_layout.addWidget(QLabel("Тип заявки:"))
        request_type_combo = QComboBox()
        request_type_combo.addItems([
            "Разработка проекта", "Перепланировка", "Замена перекрытий",
            "Замена перегородок", "Усиление", "Замена коммуникаций",
            "Пусконаладочные работы", "Проверка систем", "Другое"
        ])
        type_layout.addWidget(request_type_combo)
        layout.addLayout(type_layout)

        priority_layout = QHBoxLayout()
        priority_layout.addWidget(QLabel("Приоритет:"))
        priority_combo = QComboBox()
        priority_combo.addItems(["Низкий", "Средний", "Высокий"])
        priority_layout.addWidget(priority_combo)
        layout.addLayout(priority_layout)

        layout.addWidget(QLabel("Комментарий:"))
        comment_text = QTextEdit()
        comment_text.setPlaceholderText("Опишите суть заявки...")
        layout.addWidget(comment_text)

        file_label = QLabel("Файл: Не выбран")
        layout.addWidget(file_label)
        file_path = [None]

        def choose_file():
            # выбор файда
            path, _ = QFileDialog.getOpenFileName(dialog, "Выберите файл", "", "All Files (*);;PDF (*.pdf);;Images (*.jpg *.png)")
            if path:
                file_path[0] = path
                file_label.setText(f"Файл: {os.path.basename(path)}")

        file_btn = QPushButton("Прикрепить файл")
        file_btn.clicked.connect(choose_file)
        layout.addWidget(file_btn)

        buttons = QHBoxLayout()
        submit_btn = QPushButton("Создать")
        def submit_request():
            request_type = request_type_combo.currentText()
            priority = priority_combo.currentText()
            comment = comment_text.toPlainText().strip()
            if not comment:
                QMessageBox.warning(dialog, "Ошибка", "Введите комментарий к заявке")
                return
            # переводим на русский
            type_map = {
                "Разработка проекта": 1,
                "Перепланировка": 2,
                "Замена перекрытий": 3,
                "Замена перегородок": 4,
                "Усиление": 5,
                "Замена коммуникаций": 6,
                "Пусконаладочные работы": 7,
                "Проверка систем": 8,
                "Другое": 9
            }
            priority_map = {
                "Низкий": 1,
                "Средний": 2,
                "Высокий": 3
            }

            db_type_id = type_map.get(request_type, 9)  # значение по умолчанию
            db_priority_id = priority_map.get(priority, 2)  # значение по умолчанию
            db_status_id = 1 # значение по умолчанию
            try:
                conn = get_db_connection()
                with conn.cursor() as cursor:
                    cursor.execute("""
                        INSERT INTO requests (user_id, type_id, status_id, priority_id, comment, created_at)
                        VALUES (%s, %s, %s, %s, %s, NOW())
                    """, (self.user_data['id'], db_type_id, db_status_id, db_priority_id, comment))
                    request_id = cursor.lastrowid
                    if file_path[0]:
                        cursor.execute("""
                            INSERT INTO request_files (request_id, file_path, created_at)
                            VALUES (%s, %s, NOW())
                        """, (request_id, file_path[0]))
                    conn.commit()
                QMessageBox.information(dialog, "Успех", f"Заявка #{request_id} успешно создана")
                dialog.accept()
                self.load_requests()
            except Exception as e:
                QMessageBox.critical(dialog, "Ошибка", f"Не удалось создать заявку: {str(e)}")
            finally:
                if conn:
                    conn.close()

        submit_btn.clicked.connect(submit_request)
        buttons.addWidget(submit_btn)
        cancel_btn = QPushButton("Отмена")
        cancel_btn.clicked.connect(dialog.reject)
        buttons.addWidget(cancel_btn)
        layout.addLayout(buttons)
        dialog.setLayout(layout)
        dialog.exec()

    def check_status(self):
        # узнаем статус
        selected = self.request_table.currentRow()
        if selected >= 0:
            request_id = self.request_table.item(selected, 0).text()
            try:
                conn = get_db_connection()
                with conn.cursor() as cursor:
                    cursor.execute("""
                        SELECT rt.description AS type, rs.description AS status, 
                               rp.description AS priority, r.created_at
                        FROM requests r
                        JOIN request_types rt ON r.type_id = rt.id
                        JOIN request_statuses rs ON r.status_id = rs.id
                        JOIN request_priorities rp ON r.priority_id = rp.id
                        WHERE r.id = %s
                    """, (request_id,))
                    req = cursor.fetchone()
                    if req:
                        msg = f"Заявка #{request_id}\n" \
                              f"Тип: {req['type']}\n" \
                              f"Статус: {req['status']}\n" \
                              f"Приоритет: {req['priority']}\n" \
                              f"Дата создания: {req['created_at']}"
                        QMessageBox.information(self, "Статус заявки", msg)
                    else:
                        QMessageBox.warning(self, "Ошибка", "Заявка не найдена")
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Ошибка проверки статуса: {str(e)}")
            finally:
                if conn:
                    conn.close()
        else:
            QMessageBox.warning(self, "Ошибка", "Выберите заявку")

    def show_request_details(self):
        # окно с перепиской и заявками
        selected = self.request_table.currentRow()
        if selected >= 0:
            request_id = self.request_table.item(selected, 0).text()

            details_dialog = QDialog(self)
            details_dialog.setWindowTitle(f"Детали заявки #{request_id}")
            details_dialog.setModal(True)
            details_dialog.resize(800, 600)

            layout = QVBoxLayout()
            # таблица с сообщениями
            layout.addWidget(QLabel("Переписка:"))
            message_table = QTableWidget()
            message_table.setColumnCount(4)
            message_table.setHorizontalHeaderLabels(["ID", "Отправитель", "Сообщение", "Дата"])
            message_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
            message_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
            message_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
            message_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
            try:
                conn = get_db_connection()
                with conn.cursor() as cursor:
                    cursor.execute("""
                        SELECT m.id, CONCAT(u.first_name, ' ', COALESCE(u.last_name, ''), ' ', COALESCE(u.middle_name, '')) AS sender_name, 
                               m.message, m.created_at
                        FROM messages m
                        JOIN users u ON m.sender_id = u.id
                        WHERE m.request_id = %s
                        ORDER BY m.created_at DESC
                    """, (request_id,))
                    messages = cursor.fetchall()
                    message_table.setRowCount(len(messages))
                    for row, msg in enumerate(messages):
                        for col, value in enumerate([
                            str(msg['id']),
                            msg['sender_name'].strip(),
                            msg['message'],
                            str(msg['created_at'])
                        ]):
                            item = QTableWidgetItem(value)
                            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                            message_table.setItem(row, col, item)
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить переписку: {str(e)}")
            finally:
                if conn:
                    conn.close()

            layout.addWidget(message_table)
            layout.addWidget(QLabel("Новое сообщение:"))
            message_input = QTextEdit()
            message_input.setPlaceholderText("Введите сообщение...")
            message_input.setFixedHeight(50)
            layout.addWidget(message_input)

            send_message_btn = QPushButton("Отправить сообщение")
            def send_message():
                message = message_input.toPlainText().strip()
                if not message:
                    QMessageBox.warning(details_dialog, "Ошибка", "Введите текст сообщения")
                    return
                try:
                    conn = get_db_connection()
                    with conn.cursor() as cursor:
                        cursor.execute("""
                            INSERT INTO messages (request_id, sender_id, message, created_at)
                            VALUES (%s, %s, %s, NOW())
                        """, (request_id, self.user_data['id'], message))
                        conn.commit()
                        cursor.execute("""
                            SELECT m.id, CONCAT(u.first_name, ' ', COALESCE(u.last_name, ''), ' ', COALESCE(u.middle_name, '')) AS sender_name, 
                                   m.message, m.created_at
                            FROM messages m
                            JOIN users u ON m.sender_id = u.id
                            WHERE m.request_id = %s
                            ORDER BY m.created_at DESC
                        """, (request_id,))
                        messages = cursor.fetchall()
                        message_table.setRowCount(len(messages))
                        for row, msg in enumerate(messages):
                            for col, value in enumerate([
                                str(msg['id']),
                                msg['sender_name'].strip(),
                                msg['message'],
                                str(msg['created_at'])
                            ]):
                                item = QTableWidgetItem(value)
                                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                                message_table.setItem(row, col, item)
                        QMessageBox.information(details_dialog, "Успех", "Сообщение отправлено")
                        message_input.clear()
                except Exception as e:
                    QMessageBox.critical(details_dialog, "Ошибка", f"Не удалось отправить сообщение: {str(e)}")
                finally:
                    if conn:
                        conn.close()

            send_message_btn.clicked.connect(send_message)
            layout.addWidget(send_message_btn)

            buttons = QHBoxLayout()
            back_btn = QPushButton("Назад")
            back_btn.clicked.connect(details_dialog.close)
            buttons.addWidget(back_btn)
            layout.addLayout(buttons)
            details_dialog.setLayout(layout)
            details_dialog.exec()

    def back_to_login(self):
        # возвращаемся на авторизацию
        self.login_dialog.show()
        self.close()