import pymysql

class Database:
    def __init__(self, host='localhost', user='root', password='', db='moek'):
        try:
            self.conn = pymysql.connect(host=host,
                                         user=user,
                                         password=password,
                                         db=db,
                                         charset='utf8mb4',
                                         cursorclass=pymysql.cursors.DictCursor)
        except Exception as e:
            print("Ошибка подключения к БД:", e)

    def execute_query(self, query, params=None):
        with self.conn.cursor() as cursor:
            cursor.execute(query, params or ())
            self.conn.commit()
            return cursor.fetchall()

    def execute_query_one(self, query, params=None):
        with self.conn.cursor() as cursor:
            cursor.execute(query, params or ())
            self.conn.commit()
            return cursor.fetchone()

    def close(self):
        self.conn.close()
