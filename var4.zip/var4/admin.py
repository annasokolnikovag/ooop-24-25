import sys
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QTableWidget, QTableWidgetItem, QPushButton, QLineEdit, QLabel,
                             QFileDialog, QMessageBox, QInputDialog)
from db import Database
from chat import ChatDialog

class AdminWindow(QMainWindow):
    def __init__(self, user_id):
        super().__init__()
        self.user_id = user_id
        self.db = Database(password='')
        self.setWindowTitle("Панель администратора")
        self.resize(800, 600)
        self.init_ui()

    # инициализация интерфейса
    def init_ui(self):
        main_widget = QWidget()
        main_layout = QVBoxLayout()

        filter_layout = QHBoxLayout()
        self.filter_input = QLineEdit()
        self.filter_input.setPlaceholderText("Введите статус для фильтрации...")
        self.btn_filter = QPushButton("Фильтровать")
        self.btn_filter.clicked.connect(self.load_requests)
        filter_layout.addWidget(QLabel("Фильтр:"))
        filter_layout.addWidget(self.filter_input)
        filter_layout.addWidget(self.btn_filter)

        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["ID", "Пользователь", "Статус", "Детали"])
        self.load_requests()

        btn_layout = QHBoxLayout()
        self.btn_change_status = QPushButton("Изменить статус")
        self.btn_change_status.clicked.connect(self.change_status)
        self.btn_open_chat = QPushButton("Открыть чат")
        self.btn_open_chat.clicked.connect(self.open_chat)
        self.btn_create_user = QPushButton("Создать пользователя")
        self.btn_create_user.clicked.connect(self.create_user)
        btn_layout.addWidget(self.btn_change_status)
        btn_layout.addWidget(self.btn_open_chat)
        btn_layout.addWidget(self.btn_create_user)

        main_layout.addLayout(filter_layout)
        main_layout.addWidget(self.table)
        main_layout.addLayout(btn_layout)

        main_widget.setLayout(main_layout)
        self.setCentralWidget(main_widget)

    # загрузка заявок с фильтрацией
    def load_requests(self):
        status_filter = self.filter_input.text().strip()
        query = "SELECT r.id, u.username, r.status, r.details FROM requests r JOIN users u ON r.user_id = u.id"
        params = ()
        if status_filter:
            query += " WHERE r.status=%s"
            params = (status_filter,)
        result = self.db.execute_query(query, params)
        self.table.setRowCount(0)
        for row_data in result:
            row = self.table.rowCount()
            self.table.insertRow(row)
            self.table.setItem(row, 0, QTableWidgetItem(str(row_data["id"])))
            self.table.setItem(row, 1, QTableWidgetItem(row_data["username"]))
            self.table.setItem(row, 2, QTableWidgetItem(row_data["status"]))
            self.table.setItem(row, 3, QTableWidgetItem(row_data["details"] or ""))

    # изменение статуса заявки
    def change_status(self):
        selected = self.table.currentRow()
        if selected < 0:
            QMessageBox.warning(self, "Ошибка", "Выберите заявку для изменения статуса.")
            return

        request_id = self.table.item(selected, 0).text()
        new_status, ok = QInputDialog.getText(self, "Изменение статуса", "Введите новый статус для заявки:")

        if ok and new_status:
            query = "UPDATE requests SET status=%s WHERE id=%s"
            try:
                self.db.execute_query(query, (new_status, request_id))
                QMessageBox.information(self, "Успех", "Статус обновлён.")
                self.load_requests()
            except Exception as e:
                QMessageBox.warning(self, "Ошибка", f"Не удалось изменить статус: {e}")

    # открытие чата
    def open_chat(self):
        selected = self.table.currentRow()
        if selected < 0:
            QMessageBox.warning(self, "Ошибка", "Выберите заявку для открытия чата.")
            return
        request_id = int(self.table.item(selected, 0).text())
        dialog = ChatDialog(request_id, self.user_id, self.db)
        dialog.exec()

    # создание нового пользователя
    def create_user(self):
        from PyQt6.QtWidgets import QInputDialog
        username, ok1 = QInputDialog.getText(self, "Новый пользователь", "Имя пользователя:")
        if not (ok1 and username):
            return
        password, ok2 = QInputDialog.getText(self, "Новый пользователь", "Пароль:", QLineEdit.EchoMode.Password)
        if not (ok2 and password):
            return
        role, ok3 = QInputDialog.getItem(self, "Новый пользователь", "Выберите роль:", ["user", "admin"], editable=False)
        if not ok3:
            return
        import hashlib
        hashed_password = hashlib.md5(password.encode('utf-8')).hexdigest()
        query = "INSERT INTO users (username, password, role) VALUES (%s, %s, %s)"
        try:
            self.db.execute_query(query, (username, hashed_password, role))
            QMessageBox.information(self, "Успех", "Пользователь создан успешно.")
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", f"Не удалось создать пользователя: {e}")
