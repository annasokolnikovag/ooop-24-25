import sys
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QTableWidget, QTableWidgetItem, QPushButton, QLineEdit, QLabel,
                             QMessageBox, QInputDialog)
from db import Database
from chat import ChatDialog


class UserWindow(QMainWindow):
    def __init__(self, user_id, username):
        super().__init__()
        self.user_id = user_id
        self.username = username
        self.db = Database(password='')
        self.setWindowTitle("Личный кабинет клиента")
        self.resize(800, 600)
        self.init_ui()

    def init_ui(self):
        main_widget = QWidget()
        main_layout = QVBoxLayout()

        filter_layout = QHBoxLayout()
        self.filter_input = QLineEdit()
        self.filter_input.setPlaceholderText("Введите статус для фильтрации...")
        self.btn_filter = QPushButton("Фильтровать")
        self.btn_filter.clicked.connect(self.load_requests)
        filter_layout.addWidget(QLabel("Фильтр:"))
        filter_layout.addWidget(self.filter_input)
        filter_layout.addWidget(self.btn_filter)

        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["ID", "Статус", "Детали", "Дата создания"])
        self.load_requests()

        btn_layout = QHBoxLayout()
        self.btn_open_chat = QPushButton("Открыть чат по заявке")
        self.btn_open_chat.clicked.connect(self.open_chat)
        self.btn_agree_details = QPushButton("Согласовать время/место")
        self.btn_agree_details.clicked.connect(self.agree_details)
        self.btn_new_request = QPushButton("Создать новую заявку")
        self.btn_new_request.clicked.connect(self.create_request)
        btn_layout.addWidget(self.btn_open_chat)
        btn_layout.addWidget(self.btn_agree_details)
        btn_layout.addWidget(self.btn_new_request)

        main_layout.addLayout(filter_layout)
        main_layout.addWidget(self.table)
        main_layout.addLayout(btn_layout)

        main_widget.setLayout(main_layout)
        self.setCentralWidget(main_widget)

    def load_requests(self):
        status_filter = self.filter_input.text().strip()
        query = "SELECT id, status, details, created_at FROM requests WHERE user_id=%s"
        params = (self.user_id,)
        if status_filter:
            query += " AND status=%s"
            params = (self.user_id, status_filter)
        result = self.db.execute_query(query, params)
        self.table.setRowCount(0)
        for row_data in result:
            row = self.table.rowCount()
            self.table.insertRow(row)
            self.table.setItem(row, 0, QTableWidgetItem(str(row_data["id"])))
            self.table.setItem(row, 1, QTableWidgetItem(row_data["status"]))
            self.table.setItem(row, 2, QTableWidgetItem(row_data["details"] or ""))
            self.table.setItem(row, 3, QTableWidgetItem(str(row_data["created_at"])))

    def open_chat(self):
        selected = self.table.currentRow()
        if selected < 0:
            QMessageBox.warning(self, "Ошибка", "Выберите заявку для открытия чата.")
            return
        request_id = int(self.table.item(selected, 0).text())
        dialog = ChatDialog(request_id, self.user_id, self.db)
        dialog.exec()

    def agree_details(self):
        selected = self.table.currentRow()
        if selected < 0:
            QMessageBox.warning(self, "Ошибка", "Выберите заявку для согласования.")
            return
        request_id = self.table.item(selected, 0).text()
        date, ok1 = QInputDialog.getText(self, "Согласование", "Введите дату встречи (гггг-мм-дд):")
        time, ok2 = QInputDialog.getText(self, "Согласование", "Введите время встречи (чч:мм):")
        place, ok3 = QInputDialog.getText(self, "Согласование", "Введите место встречи:")
        if ok1 and ok2 and ok3 and date and time and place:
            details = f"Детали: {date} {time} в {place}"
            query = "UPDATE requests SET details=%s WHERE id=%s"
            self.db.execute_query(query, (details, request_id))
            QMessageBox.information(self, "Успех", "Время и место согласованы.")
            self.load_requests()

    def create_request(self):
        details, ok = QInputDialog.getText(self, "Новая заявка", "Введите детали заявки:")
        if ok and details:
            query = "INSERT INTO requests (user_id, status, details) VALUES (%s, %s, %s)"
            self.db.execute_query(query, (self.user_id, "Новая", details))
            QMessageBox.information(self, "Успех", "Заявка создана.")
            self.load_requests()
