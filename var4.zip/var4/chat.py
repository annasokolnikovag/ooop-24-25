import os
from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QLineEdit,
                             QTextEdit, QFileDialog, QMessageBox, QComboBox)
from db import Database

class ChatDialog(QDialog):
    def __init__(self, request_id, user_id, db, parent=None):
        super().__init__(parent)
        self.request_id = request_id
        self.user_id = user_id
        self.db = db
        self.setWindowTitle("Чат с администратором")
        self.setGeometry(100, 100, 600, 400)
        self.init_ui()

    # инициализация интерфейса чата
    def init_ui(self):
        self.layout = QVBoxLayout()

        self.chat_display = QTextEdit(self)
        self.chat_display.setReadOnly(True)
        self.layout.addWidget(self.chat_display)

        self.message_input = QLineEdit(self)
        self.layout.addWidget(self.message_input)

        btn_layout = QHBoxLayout()
        self.send_button = QPushButton("Отправить", self)
        self.send_button.clicked.connect(self.send_message)

        self.open_file_button = QPushButton("Открыть файл", self)
        self.open_file_button.clicked.connect(self.open_file)

        self.attach_file_button = QPushButton("Прикрепить файл", self)
        self.attach_file_button.clicked.connect(self.attach_file)

        btn_layout.addWidget(self.send_button)
        btn_layout.addWidget(self.open_file_button)
        btn_layout.addWidget(self.attach_file_button)
        self.layout.addLayout(btn_layout)

        self.load_chat_messages()

        self.setLayout(self.layout)

    # отправка сообщения
    def send_message(self):
        message = self.message_input.text()
        if not message:
            return

        try:
            query = "INSERT INTO chat_messages (request_id, user_id, message) VALUES (%s, %s, %s)"
            self.db.execute_query(query, (self.request_id, self.user_id, message))

            self.message_input.clear()
            self.chat_display.append(f"Вы ({self.user_id}): {message}\n")

        except Exception as e:
            QMessageBox.warning(self, "Ошибка", f"Ошибка при отправке сообщения: {e}")

    # загрузка сообщений чата
    def load_chat_messages(self):
        try:
            self.chat_display.clear()

            query = "SELECT u.username, cm.message, cm.created_at, cm.file_path FROM chat_messages cm " \
                    "JOIN users u ON cm.user_id = u.id WHERE cm.request_id = %s ORDER BY cm.created_at"
            messages = self.db.execute_query(query, (self.request_id,))

            if not messages:
                self.chat_display.append("Нет сообщений в чате.")

            for msg in messages:
                message_text = f"{msg['username']} ({msg['created_at']}):\n{msg['message']}\n"
                if msg['file_path']:
                    message_text += f"[Файл: {os.path.basename(msg['file_path'])}]"
                self.chat_display.append(message_text)

        except Exception as e:
            QMessageBox.warning(self, "Ошибка", f"Ошибка при загрузке сообщений: {e}")

    # прикрепление файла
    def attach_file(self):
        try:
            file_path, _ = QFileDialog.getOpenFileName(self, "Выберите файл", "", "Все файлы (*.*)")

            if file_path:
                query = "INSERT INTO chat_messages (request_id, user_id, message, file_path) VALUES (%s, %s, %s, %s)"
                self.db.execute_query(query, (self.request_id, self.user_id, "Прикреплён файл", file_path))

                self.chat_display.append(f"Вы ({self.user_id}): [Файл: {os.path.basename(file_path)}]\n")

        except Exception as e:
            QMessageBox.warning(self, "Ошибка", f"Ошибка при прикреплении файла: {e}")

    # открытие файлов из чата
    def open_file(self):
        try:
            query = "SELECT id, file_path FROM chat_messages WHERE request_id = %s AND file_path IS NOT NULL"
            files = self.db.execute_query(query, (self.request_id,))

            if not files:
                QMessageBox.warning(self, "Ошибка", "В этом чате нет прикрепленных файлов.")
                return

            file_dialog = QDialog(self)
            file_dialog.setWindowTitle("Выберите файл для открытия")

            layout = QVBoxLayout(file_dialog)
            file_combo = QComboBox(file_dialog)
            for file in files:
                file_combo.addItem(os.path.basename(file["file_path"]), file["file_path"])

            open_button = QPushButton("Открыть файл", file_dialog)
            open_button.clicked.connect(lambda: self.open_selected_file(file_combo.currentData()))

            layout.addWidget(file_combo)
            layout.addWidget(open_button)

            file_dialog.exec()

        except Exception as e:
            QMessageBox.warning(self, "Ошибка", f"Ошибка при открытии файла: {e}")

    # открытие выбранного файла
    def open_selected_file(self, file_path):
        try:
            if file_path and os.path.exists(file_path):
                os.startfile(file_path)
            else:
                QMessageBox.warning(self, "Ошибка", "Файл не найден.")
        except Exception as e:
            QMessageBox.warning(self, "Ошибка", f"Ошибка при открытии файла: {e}")
