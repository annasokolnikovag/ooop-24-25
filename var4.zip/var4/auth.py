import hashlib
from PyQt6.QtWidgets import QDialog, QLineEdit, QPushButton, QLabel, QVBoxLayout, QMessageBox
from db import Database
from user import UserWindow
from admin import AdminWindow

class LoginForm(QDialog):
    def __init__(self):
        super().__init__()
        self.db = Database(password='')
        self.setWindowTitle("Авторизация")
        self.resize(400, 100)
        self.init_ui()

    # инициализация пользовательского интерфейса
    def init_ui(self):
        layout = QVBoxLayout()

        self.input_user = QLineEdit(self)
        self.input_user.setPlaceholderText("Имя пользователя")
        self.input_pass = QLineEdit(self)
        self.input_pass.setPlaceholderText("Пароль")
        self.input_pass.setEchoMode(QLineEdit.EchoMode.Password)

        btn_login = QPushButton("Войти", self)
        btn_login.clicked.connect(self.handle_login)

        layout.addWidget(QLabel("Введите данные для входа"))
        layout.addWidget(self.input_user)
        layout.addWidget(self.input_pass)
        layout.addWidget(btn_login)

        self.setLayout(layout)

    # обработка входа
    def handle_login(self):
        username = self.input_user.text()
        password = self.input_pass.text()
        hashed = hashlib.md5(password.encode('utf-8')).hexdigest()

        row = self.db.execute_query_one(
            "SELECT * FROM users WHERE username=%s AND password=%s",
            (username, hashed)
        )

        if row:
            if row["role"] == "admin":
                self.window = AdminWindow(row["id"])
            else:
                self.window = UserWindow(row["id"], row["username"])
            self.window.show()
            self.close()
        else:
            QMessageBox.warning(self, "Ошибка", "Неверное имя пользователя или пароль.")
